#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QSqlQueryModel>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_ajouterButton_clicked() {
    QString nom_service = ui->nomServiceEdit->text();
    QString description = ui->descriptionEdit->toPlainText();
    double prix_service = ui->prixEdit->value();

    service newService(nom_service, description, prix_service);

    if (newService.ajouter()) {
        QMessageBox::information(this, "Succès", "Le service a été ajouté avec succès !");
    } else {
        QMessageBox::warning(this, "Erreur", "Échec de l'ajout du service.");
    }
}

void MainWindow::on_afficherButton_clicked() {
    service s;
    QSqlQueryModel *model = s.afficher();
    ui->tableView_rv->setModel(model);

}

void MainWindow::on_supprimerButton_clicked() {
    QString nom_service = ui->nomServiceEdit->text();

    service s;
    if (s.supprimer(nom_service)) {
        QMessageBox::information(this, "Succès", "Le service a été supprimé avec succès !");
    } else {
        QMessageBox::warning(this, "Erreur", "Échec de la suppression du service.");
    }
}

void MainWindow::on_modifierButton_clicked() {  // Implémentation du slot pour le bouton "Modifier"
    QString nom_service = ui->nomServiceEdit->text();
    QString description = ui->descriptionEdit->toPlainText();
    int prix_service = ui->prixEdit->value();

    if (nom_service.isEmpty() || description.isEmpty() || prix_service <= 0) {
        QMessageBox::warning(this, "Champs vides", "Veuillez remplir tous les champs correctement.");
        return;
    }

    service existingService(nom_service, description, prix_service);

    if (existingService.modifier()) {
        QMessageBox::information(this, "Succès", "Le service a été modifié avec succès !");
        on_afficherButton_clicked();  // Rafraîchit l'affichage pour montrer le service modifié
    } else {
        QMessageBox::warning(this, "Erreur", "Échec de la modification du service.");
    }
}
